create procedure first(IN p_in int)
begin
  select p_in;
  set p_in = 2;
  select p_in;
end;

