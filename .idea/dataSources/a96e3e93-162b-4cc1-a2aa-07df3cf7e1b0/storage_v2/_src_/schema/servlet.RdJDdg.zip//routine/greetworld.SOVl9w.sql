create procedure greetworld()
begin
  select concat(@greet,"world");
end;

