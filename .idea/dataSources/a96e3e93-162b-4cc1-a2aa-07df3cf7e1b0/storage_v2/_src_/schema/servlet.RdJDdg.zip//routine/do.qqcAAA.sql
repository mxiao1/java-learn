create procedure do()
begin
  declare x1 varchar(10) default 'outer';
  begin
    declare x2 varchar(10) default 'inner';
    select x1;
  end;
  select x1;
end;

