create procedure xiao(IN para int)
begin
  declare var int;
  set var = para + 1;
  if var=0 then insert into test values (100,'xiao100',123,'903@wmail');
  end if ;
  if para=0 then update test set id=id+1;
  else
    update  test set id=id+2;
    end if ;
end;

