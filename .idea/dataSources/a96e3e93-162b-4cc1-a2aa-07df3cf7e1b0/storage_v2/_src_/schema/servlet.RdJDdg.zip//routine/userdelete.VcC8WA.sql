create procedure userdelete(IN p int)
begin
  delete from test
    where id=p;
end;

